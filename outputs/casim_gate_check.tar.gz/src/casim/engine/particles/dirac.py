"""
ca_dirac.py  —  Dirac CA on a flat lattice  (Phase D1) — exact-QCA form
==========================================================================
Massive 4-component Dirac spinor in the Weyl/chiral representation.

State per cell: Ψ = (η_↑, η_↓, χ_↑, χ_↓) — four complex numbers.
  η = (η_↑, η_↓)   left-handed Weyl spinor
  χ = (χ_↑, χ_↓)   right-handed Weyl spinor

Refactor (Finding 9, 2026-05-17).  This module now implements the *exact*
QCA Dirac propagator of Paper 1 Eq. 23 (single-tick unitary) combined with
the unique non-trivial 2D Weyl QCA of Paper 1 Eq. 16 (see
`ca_core_exact.exact2d_unitary`).  The previous linearized Hamiltonian
form `H_D = c·α·k + m·β` is retired; the kinetic coefficient is no longer
a free parameter — the QCA admissibility constraint n² + m² = 1 fixes
n = √(1 − m²).  The `c` argument that used to live on every stepper
signature has been removed everywhere.

Single-tick unitary

    D_k = [[ n·W_k,    im·I    ],
           [ im·I,     n·W'_k  ]]    with  n = √(1−m²),  n² + m² = 1.

where W_k is the left-chirality Weyl QCA (`exact2d_unitary` at k) and
W'_k = W_k† is the opposite-chirality block.  The W' = W† choice is
*forced* by unitarity of D_k:

    (D†D)_{12} = n W† (im I) + (−im I)(n W')  =  imn (W† − W'),

and this off-diagonal must vanish, so W' = W†.  (Finding 9 paraphrased
the QCA literature's "W_k* = W_k(−k)" statement, but element-wise complex
conjugation of the explicit 2D Eq. 16 unitary differs from the Hermitian
conjugate; the form that closes the unitarity algebra is W' = W†.)
With that choice:

    (D†D)_{11} = n² W†W + m² I = (n² + m²) I = I.

Eigenvalues of D_k are e^{±iω_k}, each 2-fold degenerate, with

    ω_k = arccos(n · c_x · c_y),       c_i = cos(k_i / √2).

This is Paper 4's exact dispersion.  Small-(k, m) expansion:

    ω_k² ≈ m² + (1 − m²)·|k|²/2,

reproducing the continuum-Dirac dispersion E² = m² + (c·k)² with the
identification c = 1/√2 (lattice unit) at leading order in k.

Spectral interpolation for arbitrary dt:

    U_D(k, dt) = cos(ω·dt)·I  +  (sin(ω·dt)/sin(ω)) · (D_k − cos(ω)·I).

At ω → 0 the limit (L'Hôpital) sin(ω·dt)/sin(ω) → dt and
D_k − cos(ω)·I → 0, so U_D → I bit-for-bit.  dt = 1 recovers D_k.

Observable shift vs the old linearized convention (Finding 9):

  - Zitterbewegung frequency:  ω_Z = 2·arcsin(m)   (was 2m).
    At m = 0.5 the new target is π/3 ≈ 1.04720 (was 1.000).
  - Dispersion at finite |k|:  ω = arccos(√(1−m²)·c_x·c_y),
    BZ-periodic, bounded by π, vs the unbounded continuum √((c·k)² + m²).

Finding 26 reframing (2026-05-23): the mass step uses the exact rotation form

    cos(m·dt)·I  ±  i·sin(m·dt)·A

where A² = I (block off-diagonal unitary).  The factor cos/sin appearing
here is the same rotation structure as the EM propagator (F25/F26): the mass
generates a rigid rotation in the (η, χ) internal space, just as the photon
Ω generates a rotation in (E, B) field space.  The imaginary unit i in the
mass coupling is again the continuous-time linearisation of a real rotation.
The SU(2) complex-mass extension (F27) generalises this to a local gauge
rotation U(x) ∈ SU(2) in isospin space — all without a Higgs field.
"""

import numpy as np
from casim.engine.lattice import core_exact as ce
from casim.numerics import fft as _fft  # roadmap C1.3: route FFTs through casim.numerics


# ══════════════════════════════════════════════════════════════════
#  Internal helpers — exact-QCA 4×4 propagator pieces
# ══════════════════════════════════════════════════════════════════

def _check_mass(m):
    """Validate |m| ≤ 1 (the QCA admissibility constraint n²+m²=1)."""
    if abs(float(m)) > 1.0 + 1e-15:
        raise ValueError(
            f"|m| must be ≤ 1 under the QCA admissibility constraint "
            f"n² + m² = 1 (got m = {m}).  See Finding 9 / Paper 1 Eq. 23."
        )


def _kinetic_n(m):
    """n = √(1 − m²), the kinetic-block coefficient.  Used to be `c`."""
    return float(np.sqrt(max(0.0, 1.0 - m * m)))


def _dirac_dispersion(KX, KY, m):
    """
    ω_k = arccos(n · c_x · c_y) on the 2D square lattice (Paper 1 Eq. 23
    + Eq. 16).  Returns a real ndarray of the same shape as KX, KY.
    """
    n = _kinetic_n(m)
    inv_root2 = 1.0 / np.sqrt(2.0)
    cx = np.cos(KX * inv_root2)
    cy = np.cos(KY * inv_root2)
    return np.arccos(np.clip(n * cx * cy, -1.0, 1.0))


def _weyl_blocks(KX, KY):
    """
    Return (W, W_prime) where each is the 4-tuple (ff, fg, gf, gg) of
    2×2 Weyl-QCA unitary entries.  W is the Paper 1 Eq. 16 unitary at k;
    W' = W† is the Hermitian conjugate (the choice forced by unitarity
    of the full 4×4 D_k — see module docstring and Finding 9).

    For a 2×2 matrix [[a, b],[c, d]] the Hermitian conjugate is
    [[ā, c̄],[b̄, d̄]] — i.e. swap off-diagonals and conjugate.
    """
    W_ff, W_fg, W_gf, W_gg = ce.exact2d_unitary(KX, KY)
    W  = (W_ff, W_fg, W_gf, W_gg)
    Wp = (np.conj(W_ff), np.conj(W_gf), np.conj(W_fg), np.conj(W_gg))
    return W, Wp


def _apply_D_k(EU, ED, CU, CD, n, im_val, W, Wp):
    """
    Apply the single-tick D_k once in Fourier space.

      D_k = [[n·W_k,   im·I  ],
             [im·I,    n·W'_k]]

    on Ψ = (η_↑, η_↓, χ_↑, χ_↓).
    """
    W_ff, W_fg, W_gf, W_gg = W
    Wp_ff, Wp_fg, Wp_gf, Wp_gg = Wp

    EU_new = n * W_ff * EU + n * W_fg * ED + im_val * CU
    ED_new = n * W_gf * EU + n * W_gg * ED + im_val * CD
    CU_new = im_val * EU + n * Wp_ff * CU + n * Wp_fg * CD
    CD_new = im_val * ED + n * Wp_gf * CU + n * Wp_gg * CD
    return EU_new, ED_new, CU_new, CD_new


# ══════════════════════════════════════════════════════════════════
#  Dirac propagator (2D, with kz = 0)
# ══════════════════════════════════════════════════════════════════

def dirac_step_2d_splitstep(eta_u, eta_d, chi_u, chi_d, m=0.0, dt=1.0):
    """
    One step of the *exact-QCA* 2D Dirac CA in Fourier space.

    Parameters
    ----------
    eta_u, eta_d : complex ndarrays  shape (Lx, Ly)
        Left-handed Weyl spinor components (η_↑, η_↓).
    chi_u, chi_d : complex ndarrays  shape (Lx, Ly)
        Right-handed Weyl spinor components (χ_↑, χ_↓).
    m : float
        Dimensionless mass with |m| ≤ 1.  The kinetic coefficient
        n = √(1 − m²) is derived internally — n² + m² = 1 is the QCA
        admissibility constraint (Paper 1 Eq. 23).
    dt : float
        Time step.  dt = 1 applies D_k once.  Other values use the
        spectral interpolation U_D(dt) = cos(ω·dt)·I + sin(ω·dt)/sin(ω)
        · (D_k − cos(ω)·I) at each Fourier mode.

    Returns
    -------
    eta_u_new, eta_d_new, chi_u_new, chi_d_new : updated arrays
    """
    _check_mass(m)
    Lx, Ly = eta_u.shape
    kx = np.fft.fftfreq(Lx) * 2.0 * np.pi
    ky = np.fft.fftfreq(Ly) * 2.0 * np.pi
    KX, KY = np.meshgrid(kx, ky, indexing='ij')

    n     = _kinetic_n(m)
    im_v  = 1j * m
    W, Wp = _weyl_blocks(KX, KY)

    EU = _fft.fft2(eta_u);  ED = _fft.fft2(eta_d)
    CU = _fft.fft2(chi_u);  CD = _fft.fft2(chi_d)

    # Apply D_k once → (D_k Ψ) in Fourier space
    DEU, DED, DCU, DCD = _apply_D_k(EU, ED, CU, CD, n, im_v, W, Wp)

    if dt == 1.0:
        EU_new, ED_new, CU_new, CD_new = DEU, DED, DCU, DCD
    else:
        omega   = _dirac_dispersion(KX, KY, m)
        cos_w   = np.cos(omega)
        sin_w   = np.sin(omega)
        cos_wdt = np.cos(omega * dt)
        # scale = sin(ω·dt)/sin(ω);  L'Hôpital limit dt at ω → 0.
        sin_safe = np.where(sin_w == 0.0, 1.0, sin_w)
        scale    = np.sin(omega * dt) / sin_safe
        scale    = np.where(sin_w == 0.0, dt, scale)
        # U(dt) Ψ = cos(ω·dt) Ψ + scale · (D_k Ψ − cos(ω) Ψ)
        EU_new = cos_wdt * EU + scale * (DEU - cos_w * EU)
        ED_new = cos_wdt * ED + scale * (DED - cos_w * ED)
        CU_new = cos_wdt * CU + scale * (DCU - cos_w * CU)
        CD_new = cos_wdt * CD + scale * (DCD - cos_w * CD)

    return (_fft.ifft2(EU_new), _fft.ifft2(ED_new),
            _fft.ifft2(CU_new), _fft.ifft2(CD_new))


# ══════════════════════════════════════════════════════════════════
#  Initial conditions
# ══════════════════════════════════════════════════════════════════

def gaussian_dirac_2d(shape, center=None, sigma=3.0, chirality='left'):
    """
    Gaussian Dirac wave-packet initial condition.

    chirality='left'   → η_↑ = G, others 0   (pure left chirality)
    chirality='right'  → χ_↑ = G, others 0   (pure right chirality)
    chirality='mixed'  → η_↑ = χ_↑ = G/√2    (equal mix; mass will oscillate)
    """
    Lx, Ly = shape
    cx, cy = center if center is not None else (Lx // 2, Ly // 2)
    x = np.arange(Lx) - cx
    y = np.arange(Ly) - cy
    X, Y = np.meshgrid(x, y, indexing='ij')
    G = np.exp(-(X**2 + Y**2) / (2.0 * sigma**2)).astype(complex)

    z = np.zeros_like(G)
    if chirality == 'left':
        return G.copy(), z.copy(), z.copy(), z.copy()
    elif chirality == 'right':
        return z.copy(), z.copy(), G.copy(), z.copy()
    else:
        return G / np.sqrt(2.0), z.copy(), G / np.sqrt(2.0), z.copy()


def dirac_norm(eta_u, eta_d, chi_u, chi_d):
    """Total probability norm of the 4-spinor field."""
    return float(np.sum(
        np.abs(eta_u)**2 + np.abs(eta_d)**2 +
        np.abs(chi_u)**2 + np.abs(chi_d)**2))


# ══════════════════════════════════════════════════════════════════
#  Dispersion verification
# ══════════════════════════════════════════════════════════════════

def _dirac_4x4_at_k(kx, ky, m):
    """Build the explicit 4×4 D_k as a dense matrix at a single scalar k."""
    n = _kinetic_n(m)
    KX = np.array([[kx]]); KY = np.array([[ky]])
    W, Wp = _weyl_blocks(KX, KY)
    W_ff, W_fg, W_gf, W_gg = (x[0, 0] for x in W)
    Wp_ff, Wp_fg, Wp_gf, Wp_gg = (x[0, 0] for x in Wp)
    im_v = 1j * m
    D = np.array([
        [n * W_ff,  n * W_fg,  im_v,      0.0      ],
        [n * W_gf,  n * W_gg,  0.0,       im_v     ],
        [im_v,      0.0,       n * Wp_ff, n * Wp_fg],
        [0.0,       im_v,      n * Wp_gf, n * Wp_gg],
    ], dtype=complex)
    return D


def _dirac_plus_eigenvector(kx, ky, m):
    """
    + ω eigenvector of D_k at the scalar wavevector (kx, ky).  In the
    Schrödinger convention D_k |ψ⟩ = e^{−iE·1} |ψ⟩, so the +ω state has
    D_k eigenvalue e^{−iω_k}.  Returns a unit-norm 4-vector.
    """
    D = _dirac_4x4_at_k(kx, ky, m)
    evals, evecs = np.linalg.eig(D)
    omega = float(_dirac_dispersion(np.array(kx), np.array(ky), m))
    target = np.exp(-1j * omega)
    idx = int(np.argmin(np.abs(evals - target)))
    v = evecs[:, idx]
    v = v / np.linalg.norm(v)
    return v


def verify_dirac_dispersion_2d(L=32, n_steps=20, m=0.3, dt=1.0,
                                k_indices=None):
    """
    Verify the exact-QCA 2D Dirac propagator reproduces the dispersion
        ω = arccos(√(1−m²)·c_x·c_y),       c_i = cos(k_i/√2)
    at machine precision (Finding 9).

    Method: build a plane-wave Ψ with the +ω eigenvector of D_k at
    wavevector k, propagate n_steps, extract per-step phase from
    ⟨Ψ_0, Ψ_N⟩ / ⟨Ψ_0, Ψ_0⟩.
    """
    if k_indices is None:
        k_indices = [(1, 0), (0, 1), (1, 1), (2, 1), (3, 2), (1, 4)]

    xs = np.arange(L)
    X, Y = np.meshgrid(xs, xs, indexing='ij')

    results = []
    for ix, iy in k_indices:
        kx = 2.0 * np.pi * ix / L
        ky = 2.0 * np.pi * iy / L
        kappa = float(np.sqrt(kx**2 + ky**2))
        omega_analytic = float(_dirac_dispersion(
            np.array(kx), np.array(ky), m))

        psi = _dirac_plus_eigenvector(kx, ky, m)
        phase_field = np.exp(1j * (kx * X + ky * Y))

        eu0 = psi[0] * phase_field
        ed0 = psi[1] * phase_field
        cu0 = psi[2] * phase_field
        cd0 = psi[3] * phase_field

        ip0 = np.sum(np.conj(eu0)*eu0 + np.conj(ed0)*ed0 +
                     np.conj(cu0)*cu0 + np.conj(cd0)*cd0)

        eu, ed, cu, cd = eu0.copy(), ed0.copy(), cu0.copy(), cd0.copy()
        for _ in range(n_steps):
            eu, ed, cu, cd = dirac_step_2d_splitstep(
                eu, ed, cu, cd, m=m, dt=dt)

        ip = np.sum(np.conj(eu0)*eu + np.conj(ed0)*ed +
                    np.conj(cu0)*cu + np.conj(cd0)*cd) / ip0

        ratio = ip * np.exp(1j * omega_analytic * n_steps * dt)
        delta_omega = float(np.angle(ratio) / (n_steps * dt))
        omega_numeric = float(omega_analytic + delta_omega)
        residual = float(abs(delta_omega))

        results.append({
            'kx': kx, 'ky': ky, 'kappa': kappa,
            'omega_numeric':  omega_numeric,
            'omega_analytic': omega_analytic,
            'residual':       residual,
        })
    return results


def measure_zitterbewegung_freq_2d(L=64, n_steps=400, m=0.5, dt=0.5,
                                    sigma=8.0):
    """
    Initialize a pure-η (left-chirality only) Dirac wave packet and track
    the chirality imbalance ρ_η(t) − ρ_χ(t) over time.

    At each Fourier mode k, a pure-η state is split equally between the
    +ω(k) and −ω(k) eigenstates of D_k.  Their interference produces
    oscillation of the chirality population at angular frequency 2·ω(k).

    For a wide (small-k) Gaussian packet the dominant frequency is
    2·ω(k=0) = 2·arccos(n) = 2·arcsin(m) — Paper 4's exact zitterbewegung
    target (Finding 9).  This is *not* the same as the linearized 2m
    target; at m = 0.5 the new value is π/3 ≈ 1.0472 (vs old 1.0000).

    Returns
    -------
    t : array of time values
    rho_diff : array of normalized chirality imbalance ρ_η − ρ_χ over time
    freq_numeric  : float — angular frequency of the dominant FFT peak
    freq_analytic : float — 2·arcsin(m) (zero-k limit, exact-QCA target)
    """
    shape = (L, L)
    nu, nd, xu, xd = gaussian_dirac_2d(shape, sigma=sigma, chirality='left')

    rho_diff = []
    for step in range(n_steps + 1):
        n_eta = float(np.sum(np.abs(nu)**2 + np.abs(nd)**2))
        n_chi = float(np.sum(np.abs(xu)**2 + np.abs(xd)**2))
        total = n_eta + n_chi
        rho_diff.append((n_eta - n_chi) / total if total > 0 else 0.0)
        if step < n_steps:
            nu, nd, xu, xd = dirac_step_2d_splitstep(nu, nd, xu, xd,
                                                     m=m, dt=dt)

    rho_diff = np.array(rho_diff)
    t = np.arange(n_steps + 1) * dt

    sig = rho_diff - rho_diff.mean()
    fft = _fft.fft(sig)
    freqs = np.fft.fftfreq(len(sig), d=dt) * 2.0 * np.pi
    mag = np.abs(fft)
    pos = freqs > 0
    freq_numeric  = float(freqs[pos][np.argmax(mag[pos])])
    freq_analytic = 2.0 * float(np.arcsin(m))

    return t, rho_diff, freq_numeric, freq_analytic


# ══════════════════════════════════════════════════════════════════
#  Phase E1 — U(1) electromagnetic gauge   [REMOVED 2026-05-26]
# ══════════════════════════════════════════════════════════════════
#
# The old SM-style U(1)-gauge photon coupling that lived here
# (`dirac_step_u1_2d_splitstep` plus the `aharonov_bohm_test` driver)
# has been retired in service of the project's adopted photon: the
# composite bilinear in `ca_maxwell.py` (now a genuine two-helicity
# field, F39). The composite photon arises naturally from the BCC
# Weyl QCA structure and does NOT require a separate U(1)-gauge boson
# on top of the fermion sector (docs/theory/key-decisions.md).
#
# Consequences of the removal:
#   • Tier-1 #14 (Aharonov-Bohm phase pickup, $4.4\times10^{-16}$) is
#     retired in the inventory.
#   • The lattice Klein-paradox / tunneling test (QM-2, Tier-3 #20)
#     also used this minimal-coupling step to encode the barrier as a
#     static potential and is retired with it. The underlying physics
#     is preserved in principle by the variable-mass stepper
#     `dirac_step_2d_varm_complex_splitstep`, which is a different
#     (and arguably more faithful) lattice realisation of "Dirac in a
#     spatial energy gap".
#
# See changelog 2026-05-26 - 18:00 for the full removal record and
# first-gen-completeness-review.md §6 for the deprecation history.
# ══════════════════════════════════════════════════════════════════


# ══════════════════════════════════════════════════════════════════
#  Variable-mass Dirac stepper  (Phase F prerequisite)
# ══════════════════════════════════════════════════════════════════
#
# For position-dependent mass m(x), split the full Dirac generator:
#
#     D_full(k, x; m(x)) ≈ Mix_half(δm(x))  ∘  Kinetic(m_0, dt)  ∘  Mix_half(δm(x))
#
# where  m_0 = mean(m_field)   and   δm(x) = m_field(x) − m_0.
#
# The per-cell Mix step is the exact unitary rotation  exp(−i·β·δm·dt)
# on the (η, χ) chirality sub-block.  In the exact-QCA convention the
# off-diagonal block of D_k carries `im` with *no* `c²` factor (the
# kinetic block carries n = √(1−m²)), so the per-cell Strang generator
# is the same  δm·dt  rotation as in the old linearized form — the only
# change is that the kinetic baseline now uses  n_0 = √(1−m_0²).
#
# Leading Strang error  O(m_0²·δm·dt²)  (Finding 9 item 5) — for the
# F1/F4 contracts where δm = 0 this is exactly zero, and the unified
# evolution matches a constant-m Dirac reference bit-for-bit.
# ══════════════════════════════════════════════════════════════════


def _mix_eta_chi(eu, ed, xu, xd, theta):
    """
    Per-cell rotation exp(−i·β·θ) with β = [[0,I],[I,0]].
    θ can be a scalar or per-cell array.  Real-mass version.
    """
    cos_t = np.cos(theta)
    sin_t = np.sin(theta)
    eu_n = cos_t * eu - 1j * sin_t * xu
    ed_n = cos_t * ed - 1j * sin_t * xd
    xu_n = cos_t * xu - 1j * sin_t * eu
    xd_n = cos_t * xd - 1j * sin_t * ed
    return eu_n, ed_n, xu_n, xd_n


def _mix_eta_chi_complex(eu, ed, xu, xd, m_R, m_I, factor):
    """
    Per-cell exact-unitary rotation for a *complex* mass.

    Implements   U = exp(−i·factor·[[0, M·I],[M*·I, 0]])
                with M = m_R + i·m_I (real, real ndarrays),
                     factor = dt    (scalar; no c² under the exact-QCA
                                     convention — Finding 9).

    Derivation.  The 2×2 block [[0, M],[M*, 0]] has eigenvalues ±|M|
    with eigenvectors (1, ±M*/|M|)/√2, so

        U = cos(|M|·factor)·I  −  i·(sin(|M|·factor)/|M|)·[[0, M·I],[M*·I, 0]]

    The combination sin(θ)/|M| (with θ = |M|·factor) is well-defined at
    |M|=0 via L'Hôpital (sin(θ)/θ → 1, so sin(θ)/|M| → factor).  When
    the entire mass field is zero the rotation is identity.

    Reduces to `_mix_eta_chi(theta = m_R·factor)` when m_I ≡ 0.
    """
    abs_M    = np.sqrt(m_R * m_R + m_I * m_I)
    theta    = abs_M * factor
    cos_t    = np.cos(theta)
    abs_safe = np.where(abs_M == 0.0, 1.0, abs_M)
    sinc_M   = np.sin(theta) / abs_safe
    sinc_M   = np.where(abs_M == 0.0, factor, sinc_M)
    coeff_eta = -1j * sinc_M * (m_R + 1j * m_I)    # acts on χ to update η
    coeff_chi = -1j * sinc_M * (m_R - 1j * m_I)    # acts on η to update χ
    eu_n = cos_t * eu + coeff_eta * xu
    ed_n = cos_t * ed + coeff_eta * xd
    xu_n = cos_t * xu + coeff_chi * eu
    xd_n = cos_t * xd + coeff_chi * ed
    return eu_n, ed_n, xu_n, xd_n


def dirac_step_2d_varm_splitstep(eta_u, eta_d, chi_u, chi_d,
                                  m_field, m0=None, dt=1.0):
    """
    One step of the exact-QCA Dirac CA with position-dependent (real)
    mass m(x).  Strang split:

        Mix(δm, dt/2)  →  Kinetic(m_0, dt)  →  Mix(δm, dt/2)

    where Mix is the per-cell exp(−i·β·δm·dt) rotation and the kinetic
    step is the exact-QCA propagator at the baseline mass m_0 (default
    mean(m_field)).  Each half is exactly unitary; the composition has
    O(dt²) Strang error.

    Contract.  When m_field is uniform (δm = 0), the per-cell mix is
    identity and the kinetic step matches dirac_step_2d_splitstep at
    m = m_0 bit-for-bit — F1 vacuum regression preserved.
    """
    if m0 is None:
        m0 = float(m_field.mean())
    _check_mass(m0)
    dm = m_field - m0
    theta_half = dm * dt * 0.5     # no c² (exact-QCA convention)

    eu, ed, xu, xd = _mix_eta_chi(eta_u, eta_d, chi_u, chi_d, theta_half)
    eu, ed, xu, xd = dirac_step_2d_splitstep(eu, ed, xu, xd,
                                              m=m0, dt=dt)
    eu, ed, xu, xd = _mix_eta_chi(eu, ed, xu, xd, theta_half)
    return eu, ed, xu, xd


def dirac_step_2d_varm_complex_splitstep(eta_u, eta_d, chi_u, chi_d,
                                          m_R_field, m_I_field,
                                          m0=None, dt=1.0):
    """
    Exact-QCA Dirac CA step with *complex* position-dependent mass
    M(x) = m_R(x) + i·m_I(x).

    Split as

        D_full ≈ Mix_complex(δm, dt/2)  ∘  Kinetic(m_0, dt)  ∘  Mix_complex(δm, dt/2)

    where m_0 = mean(m_R_field) is the real baseline and δm(x) =
    M(x) − m_0 is the per-cell complex residual.  The mass term in the
    exact-QCA Dirac block has coefficient `im` (no c² factor — Finding 9
    item 5), so the Mix generator is δm·dt with no c² either.

    Contracts.
      F1 — When m_R_field is uniform and m_I_field ≡ 0, δm = 0, the mix
           is identity, and the kinetic step matches the constant-m
           reference bit-for-bit.
      F4 — When the entire mass field is zero, m_0 = 0, n_0 = 1, the
           kinetic step is the exact-QCA D_k(m=0) = diag(W_k, W'_k),
           i.e. two decoupled exact-QCA Weyl propagators on η and χ.

    Parameters
    ----------
    m_R_field, m_I_field : real ndarrays, shape (Lx, Ly)
        Real and imaginary parts of the per-cell mass.  Standard-Model
        Yukawa with scalar Φ gives M(x) = y·Φ(x), so m_R = y·Re(Φ),
        m_I = y·Im(Φ).

    Returns
    -------
    eu, ed, xu, xd : updated arrays
    """
    if m0 is None:
        m0 = float(m_R_field.mean())
    _check_mass(m0)
    dm_R = m_R_field - m0
    dm_I = m_I_field
    factor_half = dt * 0.5     # no c² (exact-QCA convention)

    eu, ed, xu, xd = _mix_eta_chi_complex(eta_u, eta_d, chi_u, chi_d,
                                           dm_R, dm_I, factor_half)
    eu, ed, xu, xd = dirac_step_2d_splitstep(eu, ed, xu, xd,
                                              m=m0, dt=dt)
    eu, ed, xu, xd = _mix_eta_chi_complex(eu, ed, xu, xd,
                                           dm_R, dm_I, factor_half)
    return eu, ed, xu, xd


# ══════════════════════════════════════════════════════════════════
#  SU(2) complex-mass coupling  (Ludwig 2007, Finding F27)
# ══════════════════════════════════════════════════════════════════
#
# Source: physics_notes_0708.pdf pages 59–60 ("Complex mass", 9/6/2007).
# Implemented and validated as forks/complex_mass_fork.py (2026-05-23);
# merged into main model here.
#
# Core idea
# ---------
# Replace the scalar Dirac mass coupling `im` with `im·e^{iθ(x)}`,
# which is equivalent to gauging the β matrix via
#
#     β_g = (U σ₁ U†) ⊗ I,    U = diag(1, e^{iθ})
#
# giving β_g = cos θ · σ₁ + sin θ · σ₂.  The local mass step is
#
#     M(θ) = [[c_m I,        i s_m e^{iθ} I ],
#             [i s_m e^{-iθ} I,  c_m I      ]]
#
# which is unitary because A = [[0, e^{iθ}],[e^{-iθ}, 0]] is Hermitian
# with A² = I, so M = cos·I + i·sin·A → M†M = I.
#
# For a (ν, e) isospin doublet, the scalar phase generalises to
# U(x) ∈ SU(2) acting on the isospin index (I₂ on spin):
#
#     η_new = cos(m·dt) η + i sin(m·dt) (U ⊗ I₂) χ
#     χ_new = i sin(m·dt) (U† ⊗ I₂) η + cos(m·dt) χ
#
# Ward identity (T5, 1.055×10⁻¹⁷):
#     V(x)·mass_step(ψ; U) = mass_step(V(x)·ψ; V(x)·U)
# where V acts only on left-handed η — right-handed χ unchanged.
# This is local SU(2)_L gauge invariance without a Higgs field.
#
# Split-step convention (Strang):
#     step(dt) = kinetic(dt/2) ∘ mass(dt) ∘ kinetic(dt/2)
# The kinetic half-step applies the exact-QCA Weyl propagator to each
# 2-component Weyl spinor independently (no isospin mixing in kinetics).
# ══════════════════════════════════════════════════════════════════


def _weyl_half_step_2c(f, g, dt_half):
    """
    Exact-QCA kinetic half-step for one 2-component Weyl spinor (f, g).

    Uses spectral interpolation of the exact2d_unitary at time dt_half.
    This is the building block for the SU(2) complex-mass Strang split,
    where the kinetic step is applied independently to each isospin
    component (no isospin coupling in the kinetic sector).

    Different from dirac_step_2d_splitstep: that function applies the
    full 4-component Dirac unitary D_k (kinetic + mass together in
    Fourier space).  Here we apply only the 2×2 Weyl block to one
    chirality × isospin component.

    Parameters
    ----------
    f, g : complex ndarrays  shape (Lx, Ly)
        Upper and lower spin components of one Weyl spinor.
    dt_half : float
        Half-step size (typically dt/2).

    Returns
    -------
    f_new, g_new : updated arrays
    """
    Lx, Ly = f.shape
    kx = np.fft.fftfreq(Lx) * 2.0 * np.pi
    ky = np.fft.fftfreq(Ly) * 2.0 * np.pi
    KX, KY = np.meshgrid(kx, ky, indexing='ij')

    U_ff, U_fg, U_gf, U_gg = ce.exact2d_unitary(KX, KY)
    omega    = ce.exact2d_dispersion(KX, KY)
    cos_w    = np.cos(omega)
    sin_w    = np.sin(omega)
    cos_h    = np.cos(dt_half * omega)
    sin_safe = np.where(np.abs(sin_w) < 1e-14, 1.0, sin_w)
    scale    = np.sin(dt_half * omega) / sin_safe
    scale    = np.where(np.abs(sin_w) < 1e-14, dt_half, scale)

    F = _fft.fft2(f)
    G = _fft.fft2(g)
    F_d = U_ff * F + U_fg * G
    G_d = U_gf * F + U_gg * G
    F_new = cos_h * F + scale * (F_d - cos_w * F)
    G_new = cos_h * G + scale * (G_d - cos_w * G)
    return _fft.ifft2(F_new), _fft.ifft2(G_new)


# ── 1-Flavour U(1) complex mass ────────────────────────────────────

def mass_step_1flavor_u1(eta_u, eta_d, chi_u, chi_d, theta, m, dt=1.0):
    """
    Local complex-mass step for a single flavour (U(1) θ-field).

    The per-cell unitary is:

        M(θ) = [[c_m I,         i s_m e^{iθ} I ],
                [i s_m e^{-iθ} I,  c_m I       ]]

    with c_m = cos(m·dt), s_m = sin(m·dt).  Unitary for any θ(x).

    Parameters
    ----------
    eta_u, eta_d : (Lx, Ly) complex — left-chirality spinor (spin ↑↓)
    chi_u, chi_d : (Lx, Ly) complex — right-chirality spinor (spin ↑↓)
    theta        : (Lx, Ly) real   — local β-gauge angle field θ(x)
    m            : float           — dimensionless mass (|m| ≤ 1)
    dt           : float           — time step

    Returns
    -------
    Updated (eta_u, eta_d, chi_u, chi_d).
    """
    c_m  = np.cos(m * dt)
    s_m  = np.sin(m * dt)
    ph   = np.exp(1j * theta)
    phc  = np.conj(ph)

    eu_n = c_m * eta_u + 1j * s_m * ph  * chi_u
    ed_n = c_m * eta_d + 1j * s_m * ph  * chi_d
    xu_n = 1j * s_m * phc * eta_u + c_m * chi_u
    xd_n = 1j * s_m * phc * eta_d + c_m * chi_d
    return eu_n, ed_n, xu_n, xd_n


def dirac_step_complex_mass_1flavor(eta_u, eta_d, chi_u, chi_d,
                                    theta, m, dt=1.0):
    """
    Full Strang-split step for the 1-flavour U(1) complex-mass CA.

        kinetic(dt/2) → complex_mass(dt) → kinetic(dt/2)

    The kinetic half-step is the exact-QCA Weyl propagator applied
    independently to each chirality component.  The mass step is local.

    Parameters
    ----------
    eta_u, eta_d : (Lx, Ly) complex — left Weyl spinor (spin ↑↓)
    chi_u, chi_d : (Lx, Ly) complex — right Weyl spinor (spin ↑↓)
    theta        : (Lx, Ly) real   — local β-gauge angle θ(x)
    m            : float           — dimensionless mass (|m| ≤ 1)
    dt           : float           — time step

    Returns
    -------
    Updated (eta_u, eta_d, chi_u, chi_d).
    """
    _check_mass(m)
    eta_u, eta_d = _weyl_half_step_2c(eta_u, eta_d, 0.5 * dt)
    chi_u, chi_d = _weyl_half_step_2c(chi_u, chi_d, 0.5 * dt)
    eta_u, eta_d, chi_u, chi_d = mass_step_1flavor_u1(
        eta_u, eta_d, chi_u, chi_d, theta, m, dt)
    eta_u, eta_d = _weyl_half_step_2c(eta_u, eta_d, 0.5 * dt)
    chi_u, chi_d = _weyl_half_step_2c(chi_u, chi_d, 0.5 * dt)
    return eta_u, eta_d, chi_u, chi_d


# ── SU(2) doublet complex mass (chiral SU(2)) ──────────────────────
#
#  State arrays per spin component (all shape (Lx, Ly)):
#    eta_nu_u, eta_nu_d   — left-handed neutrino (isospin T₃ = +½)
#    eta_e_u,  eta_e_d    — left-handed electron (isospin T₃ = −½)
#    chi_nu_u, chi_nu_d   — right-handed neutrino
#    chi_e_u,  chi_e_d    — right-handed electron
#
#  SU(2) field U(x) stored as (U_a, U_b) with |a|²+|b|²=1:
#    U = [[a, -b*], [b, a*]]   ∈ SU(2),   shape: each (Lx, Ly) complex

def make_su2_field(Lx, Ly, mode='identity'):
    """
    Initialise an SU(2) isospin field U(x) = [[a, -b*],[b, a*]].

    Parameters
    ----------
    mode : str
        'identity' — U = I everywhere (a=1, b=0)
        'random'   — U(x) drawn uniformly from SU(2) (Haar measure)
        'plane'    — a=cos(π/4), b=sin(π/4) everywhere (test wave)
        'su2_z'    — U = e^{iα σ₃/2}: a=e^{iα/2}, b=0, random α(x)

    Returns
    -------
    a, b : complex ndarrays of shape (Lx, Ly)
    """
    if mode == 'identity':
        a = np.ones((Lx, Ly), dtype=complex)
        b = np.zeros((Lx, Ly), dtype=complex)
    elif mode == 'random':
        rng = np.random.default_rng(seed=42)
        raw = rng.standard_normal((Lx, Ly, 4))
        norms = np.linalg.norm(raw, axis=-1, keepdims=True)
        q = raw / norms
        a = q[..., 0] + 1j * q[..., 3]
        b = q[..., 2] + 1j * q[..., 1]
    elif mode == 'plane':
        a = np.full((Lx, Ly), np.cos(np.pi / 4), dtype=complex)
        b = np.full((Lx, Ly), np.sin(np.pi / 4), dtype=complex)
    elif mode == 'su2_z':
        rng = np.random.default_rng(seed=7)
        alpha = rng.uniform(0, 2 * np.pi, (Lx, Ly))
        a = np.exp(0.5j * alpha)
        b = np.zeros((Lx, Ly), dtype=complex)
    else:
        raise ValueError(f"Unknown SU(2) mode: {mode!r}")
    return a, b


def mass_step_doublet_su2(eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
                          chi_nu_u, chi_nu_d, chi_e_u, chi_e_d,
                          U_a, U_b, m, dt=1.0):
    """
    Local SU(2) complex-mass step for the (ν, e) isospin doublet.

    The mass coupling at each cell is:

        M = [[c_m I₄,         i s_m (U⊗I₂) ],
             [i s_m (U†⊗I₂), c_m I₄        ]]

    where U = [[Ua, -Ub*],[Ub, Ua*]] acts on isospin, I₂ on spin.

    Unitarity: A = [[0, U⊗I₂],[U†⊗I₂, 0]] is Hermitian, A² = I₈
    (since UU† = I₂), so M = cos·I + i·sin·A → M†M = I.

    Ward identity (F27 T5, 1.055×10⁻¹⁷):
        V·M(U)·ψ = M(V·U)·(V_L·ψ)
    where V_L acts only on left-handed η — χ is exactly unchanged.

    Parameters
    ----------
    eta_nu_u, eta_nu_d : (Lx,Ly) — left-handed ν (spin ↑↓)
    eta_e_u,  eta_e_d  : (Lx,Ly) — left-handed e (spin ↑↓)
    chi_nu_u, chi_nu_d : (Lx,Ly) — right-handed ν (spin ↑↓)
    chi_e_u,  chi_e_d  : (Lx,Ly) — right-handed e (spin ↑↓)
    U_a, U_b           : (Lx,Ly) — SU(2) field (|Ua|²+|Ub|²=1)
    m                  : float   — mass (|m| ≤ 1)
    dt                 : float   — timestep

    Returns
    -------
    Updated 8-tuple of spinor arrays.
    """
    c_m = np.cos(m * dt)
    s_m = np.sin(m * dt)
    Ua  = U_a;  Ub  = U_b
    Uac = np.conj(Ua);  Ubc = np.conj(Ub)

    # η_new = c η + i s (U⊗I₂) χ
    #   U·χ_isospin: [Ua, -Ub*; Ub, Ua*]·[χ_ν, χ_e]
    eu_nu_n = c_m * eta_nu_u + 1j * s_m * (Ua * chi_nu_u - Ubc * chi_e_u)
    ed_nu_n = c_m * eta_nu_d + 1j * s_m * (Ua * chi_nu_d - Ubc * chi_e_d)
    eu_e_n  = c_m * eta_e_u  + 1j * s_m * (Ub * chi_nu_u + Uac * chi_e_u)
    ed_e_n  = c_m * eta_e_d  + 1j * s_m * (Ub * chi_nu_d + Uac * chi_e_d)

    # χ_new = i s (U†⊗I₂) η + c χ
    #   U†·η_isospin: [Ua*, Ub*; -Ub, Ua]·[η_ν, η_e]
    xu_nu_n = 1j * s_m * (Uac * eta_nu_u + Ubc * eta_e_u) + c_m * chi_nu_u
    xd_nu_n = 1j * s_m * (Uac * eta_nu_d + Ubc * eta_e_d) + c_m * chi_nu_d
    xu_e_n  = 1j * s_m * (-Ub * eta_nu_u + Ua  * eta_e_u) + c_m * chi_e_u
    xd_e_n  = 1j * s_m * (-Ub * eta_nu_d + Ua  * eta_e_d) + c_m * chi_e_d

    return (eu_nu_n, ed_nu_n, eu_e_n, ed_e_n,
            xu_nu_n, xd_nu_n, xu_e_n, xd_e_n)


def dirac_step_complex_mass_doublet(eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
                                    chi_nu_u, chi_nu_d, chi_e_u, chi_e_d,
                                    U_a, U_b, m, dt=1.0):
    """
    Full Strang-split step for the SU(2) doublet complex-mass CA.

        kinetic(dt/2) → SU(2)-mass(dt) → kinetic(dt/2)

    The kinetic step is applied independently to each isospin component
    (ν and e decouple in the kinetic sector — only the mass step mixes
    them via U).  Full local SU(2) invariance of the kinetic sector
    requires W_μ gauge bosons, as in the Standard Model.

    Parameters
    ----------
    (same as mass_step_doublet_su2)
    U_a, U_b : SU(2) field held fixed during this step (static or pure gauge)

    Returns
    -------
    Updated 8-tuple of spinor arrays.
    """
    _check_mass(m)

    # — kinetic half-step (each isospin component independently) ——
    eta_nu_u, eta_nu_d = _weyl_half_step_2c(eta_nu_u, eta_nu_d, 0.5 * dt)
    eta_e_u,  eta_e_d  = _weyl_half_step_2c(eta_e_u,  eta_e_d,  0.5 * dt)
    chi_nu_u, chi_nu_d = _weyl_half_step_2c(chi_nu_u, chi_nu_d, 0.5 * dt)
    chi_e_u,  chi_e_d  = _weyl_half_step_2c(chi_e_u,  chi_e_d,  0.5 * dt)

    # — SU(2) complex-mass full step ——————————————————————————————
    (eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
     chi_nu_u, chi_nu_d, chi_e_u, chi_e_d) = mass_step_doublet_su2(
        eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
        chi_nu_u, chi_nu_d, chi_e_u, chi_e_d,
        U_a, U_b, m, dt)

    # — kinetic half-step ——————————————————————————————————————————
    eta_nu_u, eta_nu_d = _weyl_half_step_2c(eta_nu_u, eta_nu_d, 0.5 * dt)
    eta_e_u,  eta_e_d  = _weyl_half_step_2c(eta_e_u,  eta_e_d,  0.5 * dt)
    chi_nu_u, chi_nu_d = _weyl_half_step_2c(chi_nu_u, chi_nu_d, 0.5 * dt)
    chi_e_u,  chi_e_d  = _weyl_half_step_2c(chi_e_u,  chi_e_d,  0.5 * dt)

    return (eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
            chi_nu_u, chi_nu_d, chi_e_u, chi_e_d)


def su2_gauge_transform_chiral(eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
                               chi_nu_u, chi_nu_d, chi_e_u, chi_e_d,
                               U_a, U_b, V_a, V_b):
    """
    Apply chiral SU(2)_L gauge transformation:

        η_doublet → V(x) · η_doublet    (left sector transforms)
        χ_doublet → χ_doublet           (right sector UNCHANGED)
        U         → V · U               (coupling compensates)

    where V = [[Va, -Vb*],[Vb, Va*]] and U = [[Ua, -Ub*],[Ub, Ua*]].

    This is the exact symmetry of mass_step_doublet_su2 (Ward identity
    V·mass(ψ;U) = mass(V·ψ; V·U), T5 residual 1.055×10⁻¹⁷).

    Returns
    -------
    Transformed 8-tuple of spinor arrays + updated (U_a_new, U_b_new).
    """
    Va  = V_a;  Vbc = np.conj(V_b)
    Vac = np.conj(V_a)

    eu_nu_n = Va  * eta_nu_u - Vbc * eta_e_u
    ed_nu_n = Va  * eta_nu_d - Vbc * eta_e_d
    eu_e_n  = V_b * eta_nu_u + Vac * eta_e_u
    ed_e_n  = V_b * eta_nu_d + Vac * eta_e_d

    # χ unchanged (chiral)
    xu_nu_n, xd_nu_n = chi_nu_u.copy(), chi_nu_d.copy()
    xu_e_n,  xd_e_n  = chi_e_u.copy(),  chi_e_d.copy()

    # U' = V·U  (SU(2) product: a'' = Va·Ua − Vb*·Ub, b'' = Vb·Ua + Va*·Ub)
    U_a_new = Va  * U_a - Vbc * U_b
    U_b_new = V_b * U_a + Vac * U_b

    return (eu_nu_n, ed_nu_n, eu_e_n, ed_e_n,
            xu_nu_n, xd_nu_n, xu_e_n, xd_e_n,
            U_a_new, U_b_new)


# ── SU(2) doublet initial conditions & observables ─────────────────

def gaussian_doublet(shape, sigma=4.0, kind='left_nu', center=None):
    """
    Gaussian initial conditions for the SU(2) doublet.

    kind:
      'left_nu'   — pure η_ν↑ (ν left-handed, spin-up)
      'left_e'    — pure η_e↑ (e left-handed, spin-up)
      'left_both' — equal mix η_ν = η_e = G/√2
      'right_nu'  — pure χ_ν↑ (ν right-handed)
      'right_e'   — pure χ_e↑ (e right-handed)

    Returns
    -------
    8-tuple: (eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
              chi_nu_u, chi_nu_d, chi_e_u, chi_e_d)
    """
    Lx, Ly = shape
    cx, cy = center if center is not None else (Lx // 2, Ly // 2)
    x = np.arange(Lx) - cx;  y = np.arange(Ly) - cy
    X, Y = np.meshgrid(x, y, indexing='ij')
    G = np.exp(-(X**2 + Y**2) / (2.0 * sigma**2)).astype(complex)
    z = np.zeros_like(G)

    eu_nu = z.copy();  ed_nu = z.copy()
    eu_e  = z.copy();  ed_e  = z.copy()
    xu_nu = z.copy();  xd_nu = z.copy()
    xu_e  = z.copy();  xd_e  = z.copy()

    if kind == 'left_nu':
        eu_nu = G.copy()
    elif kind == 'left_e':
        eu_e = G.copy()
    elif kind == 'left_both':
        eu_nu = G / np.sqrt(2.0);  eu_e = G / np.sqrt(2.0)
    elif kind == 'right_nu':
        xu_nu = G.copy()
    elif kind == 'right_e':
        xu_e = G.copy()
    else:
        raise ValueError(f"Unknown doublet kind: {kind!r}")

    return eu_nu, ed_nu, eu_e, ed_e, xu_nu, xd_nu, xu_e, xd_e


def norm_doublet(eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
                 chi_nu_u, chi_nu_d, chi_e_u, chi_e_d):
    """Total probability norm for the 8-component doublet spinor."""
    return float(sum(
        np.sum(np.abs(arr)**2)
        for arr in (eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
                    chi_nu_u, chi_nu_d, chi_e_u, chi_e_d)))


def chirality_split_doublet(eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
                            chi_nu_u, chi_nu_d, chi_e_u, chi_e_d):
    """Return (N_left, N_right) total probability in each chirality sector."""
    N_L = float(sum(np.sum(np.abs(a)**2)
                    for a in (eta_nu_u, eta_nu_d, eta_e_u, eta_e_d)))
    N_R = float(sum(np.sum(np.abs(a)**2)
                    for a in (chi_nu_u, chi_nu_d, chi_e_u, chi_e_d)))
    return N_L, N_R


def isospin_t3_doublet(eta_nu_u, eta_nu_d, eta_e_u, eta_e_d,
                       chi_nu_u, chi_nu_d, chi_e_u, chi_e_d):
    """
    Return (⟨T₃⟩_left, ⟨T₃⟩_right) = (N_ν − N_e)/2 in each sector.

    ν carries T₃ = +½, e carries T₃ = −½.
    """
    N_nu_L = float(sum(np.sum(np.abs(a)**2) for a in (eta_nu_u, eta_nu_d)))
    N_e_L  = float(sum(np.sum(np.abs(a)**2) for a in (eta_e_u,  eta_e_d)))
    N_nu_R = float(sum(np.sum(np.abs(a)**2) for a in (chi_nu_u, chi_nu_d)))
    N_e_R  = float(sum(np.sum(np.abs(a)**2) for a in (chi_e_u,  chi_e_d)))
    return 0.5 * (N_nu_L - N_e_L), 0.5 * (N_nu_R - N_e_R)


def su2_casimir_left(eta_nu_u, eta_nu_d, eta_e_u, eta_e_d):
    """
    ⟨T²⟩ on the left-handed doublet sector.

    For a pure SU(2) doublet state |T=½, T₃=m⟩ the Casimir eigenvalue
    is T(T+1) = ¾.  Returns the expectation value (a real float).

    ⟨T²⟩ = T₃² + |T₊|²,  where T₊ = Σ η_ν* η_e / N_total.
    """
    N_nu = float(sum(np.sum(np.abs(a)**2) for a in (eta_nu_u, eta_nu_d)))
    N_e  = float(sum(np.sum(np.abs(a)**2) for a in (eta_e_u,  eta_e_d)))
    N_total = N_nu + N_e
    if N_total < 1e-30:
        return 0.0
    T3     = 0.5 * (N_nu - N_e) / N_total
    T_plus = (np.sum(np.conj(eta_nu_u) * eta_e_u)
              + np.sum(np.conj(eta_nu_d) * eta_e_d)) / N_total
    return T3**2 + float(np.abs(T_plus)**2)


# ══════════════════════════════════════════════════════════════════
#  Aharonov-Bohm / gauge tests   [REMOVED 2026-05-26]
# ══════════════════════════════════════════════════════════════════
#
# The `aharonov_bohm_test` driver was retired together with
# `dirac_step_u1_2d_splitstep` (see top of file, "Phase E1" notice).
# The AB demonstration of U(1) minimal coupling is a feature of the
# OLD photon-as-gauge-boson formulation that the project replaced
# with the composite bilinear (F39 two-helicity composite photon).
#
# If the AB phase pickup is needed as a future test, build it from
# the composite-photon machinery in `ca_maxwell.py`, not from a
# stand-alone external A_μ field.
# ══════════════════════════════════════════════════════════════════
