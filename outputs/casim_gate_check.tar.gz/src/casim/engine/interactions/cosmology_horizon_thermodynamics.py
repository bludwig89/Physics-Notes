"""
cosmology_horizon_thermodynamics.py -- F360

Re-derives the flat-FRW Friedmann pair from a Clausius-relation (Jacobson
1995 / Cai-Kim 2005 style) argument at the cosmological apparent horizon,
using only local horizon thermodynamics -- an Unruh-type temperature set by
the model's own light cone (F26/F180, c_lat=c_grav), an entropy S=A/4G with
the model's own INDUCED G (F79), and the Clausius relation dQ=TdS -- rather
than positing and solving the covariant field equation G_mu_nu=(8 pi G/c^4)
T_mu_nu (F178) with the model's stress-energy content as input (which is
what F182/F188 do, and what F284 re-reads ontologically without changing).

This module does two things, both sympy-exact:

  1. VERIFY_QUASISTATIC -- the standard (Cai-Kim) "quasi-static apparent
     horizon" derivation: with kappa ~= -1/r_A (the horizon radius treated
     as slowly varying over one Clausius step), dQ=TdS together with the
     continuity equation reproduces BOTH Friedmann equations exactly:
         Hdot = -4 pi G (rho+p)              (Friedmann II)
         H^2  = (8 pi G / 3) rho              (Friedmann I, on integration)

  2. QUANTIFY_APPROXIMATION -- the honest check this finding adds: the term
     dropped by "kappa ~= -1/r_A" relative to the exact Hayward-Kodama
     surface gravity kappa = -(1/r_A)(1 - r_A_dot/(2 H r_A)) is NOT
     parametrically small in general. Its ratio to the leading Hdot term is
     computed in closed form and shown to equal -3(1+w)/4 exactly -- an
     O(1) number for radiation (w=1/3: ratio=-1) and matter (w=0:
     ratio=-3/4), vanishing only for a pure Lambda source (w=-1). So the
     "quasi-static" step is a *convention* that reproduces the Friedmann
     pair exactly, not a controlled small-parameter expansion.

Honest scope (see findings/F360-*.md sec. 5-6 for the full discussion):
  - The FRW symmetry ansatz (homogeneity/isotropy) is still external input,
    shared with the standard approach (and with F284's own reading) -- not
    a new gap this finding introduces or claims to close.
  - The Hayward-Kodama surface-gravity / Unruh-temperature construction and
    the coefficient 1/4 in S=A/4G are imported continuum semiclassical-
    gravity objects, not yet independently re-derived from this lattice's
    own microphysics -- the same kind of import F61 flagged for the R/4
    Lichnerowicz curvature coupling. F190/F355 track the still-open, and
    (as of F355, same day) actively DISAGREEING, lattice-native attempt to
    pin the S=A/4G coefficient from BCC microstates.
  - An attempt at the fully exact "unified first law" (Misner-Sharp energy
    + work density W=(rho-p)/2, which the literature presents as removing
    the quasi-static step) was made in this session's working notes and
    produced sign/consistency inconsistencies that could not be resolved
    with confidence; it is NOT included here as a verified result, and is
    named in the finding as unresolved future work rather than claimed.

Self-contained: sympy only.
"""

from __future__ import annotations

import sympy as sp


def _build_symbols():
    t = sp.symbols("t", real=True)
    G = sp.symbols("G", positive=True)
    H = sp.Function("H", positive=True)(t)
    rho = sp.Function("rho", positive=True)(t)
    p = sp.Function("p", real=True)(t)
    Hdot, rhodot = sp.symbols("Hdot rhodot")
    return t, G, H, rho, p, Hdot, rhodot


def verify_quasistatic() -> dict:
    """Cai-Kim quasi-static derivation: dQ=TdS + continuity => Friedmann I & II, exactly."""
    t, G, H, rho, p, Hdot, rhodot = _build_symbols()

    r_A = 1 / H
    r_A_dot = sp.diff(r_A, t)

    # quasi-static surface gravity / temperature (horizon radius slowly varying)
    kappa_qs = -1 / r_A
    T_qs = -kappa_qs / (2 * sp.pi)

    A_area = 4 * sp.pi * r_A ** 2
    S = A_area / (4 * G)
    dS_dt = sp.diff(S, t)

    dQ_dt = 4 * sp.pi * r_A ** 3 * H * (rho + p)  # energy flux through the horizon

    residual = sp.simplify(dQ_dt - T_qs * dS_dt)
    residual = residual.subs(sp.Derivative(H, t), Hdot)
    residual = sp.simplify(residual)

    Hdot_sol = sp.solve(sp.Eq(residual, 0), Hdot)
    Hdot_target = -4 * sp.pi * G * (rho + p)
    friedmann_II_match = bool(sp.simplify(Hdot_sol[0] - Hdot_target) == 0)

    # integrate via continuity: rhodot = -3H(rho+p) => (rho+p) = -rhodot/(3H)
    Hdot_via_continuity = -4 * sp.pi * G * (-rhodot / (3 * H))
    dH2_dt = sp.simplify(2 * H * Hdot_via_continuity)
    dH2_dt_target = sp.Rational(8, 3) * sp.pi * G * rhodot
    friedmann_I_rate_match = bool(sp.simplify(dH2_dt - dH2_dt_target) == 0)

    return {
        "residual_after_quasistatic": str(residual),
        "Hdot_solutions": [str(s) for s in Hdot_sol],
        "friedmann_II_exact_match": friedmann_II_match,
        "dH2_dt_matches_8piG_over_3_rhodot": friedmann_I_rate_match,
        "conclusion": (
            "H^2 = (8 pi G/3) rho recovered on integration with H->0 as rho->0"
            if friedmann_II_match and friedmann_I_rate_match
            else "MISMATCH -- derivation does not close"
        ),
    }


def quantify_approximation() -> dict:
    """Size of the term dropped by kappa ~= -1/r_A, relative to the kept Hdot term.

    Exact result: with rho+p = (1+w) rho and Friedmann I (H^2=(8 pi G/3) rho),
    the ratio of the dropped Hdot^2/(2H^2) piece to the leading Hdot piece is
    exactly -3(1+w)/4, independent of G. Verified for w=1/3 (radiation),
    w=0 (matter), w=-1 (Lambda).
    """
    w = sp.symbols("w", real=True)
    ratio_closed_form = sp.Rational(-3, 4) * (1 + w)

    cases = {}
    for label, w_val in (("radiation", sp.Rational(1, 3)), ("matter", sp.Integer(0)), ("lambda", sp.Integer(-1))):
        cases[label] = {
            "w": str(w_val),
            "ratio": str(sp.nsimplify(ratio_closed_form.subs(w, w_val))),
            "ratio_float": float(ratio_closed_form.subs(w, w_val)),
            "is_O1_not_small": bool(abs(float(ratio_closed_form.subs(w, w_val))) >= sp.Rational(1, 10)),
        }

    # independent re-derivation directly from the exact vs quasi-static kappa,
    # cross-checking the closed form above from scratch
    t, G, H, rho, p, Hdot, rhodot = _build_symbols()
    r_A = 1 / H
    r_A_dot = sp.diff(r_A, t)
    kappa_exact = -(1 / r_A) * (1 - r_A_dot / (2 * H * r_A))
    kappa_qs = -1 / r_A
    dropped_piece = sp.simplify((kappa_exact - kappa_qs))
    dropped_piece = dropped_piece.subs(sp.Derivative(H, t), Hdot)
    dropped_piece = sp.simplify(dropped_piece)

    return {
        "ratio_closed_form": "-3*(1+w)/4",
        "cases": cases,
        "dropped_kappa_piece_expression": str(dropped_piece),
        "conclusion": (
            "the quasi-static approximation drops an O(1) term for radiation and "
            "matter (ratio -1 and -3/4 respectively); it vanishes only for a pure "
            "cosmological-constant source (w=-1). This is a CONVENTION that "
            "reproduces the Friedmann pair exactly, not a small-parameter expansion."
        ),
    }


def run_all() -> dict:
    qs = verify_quasistatic()
    approx = quantify_approximation()
    passed = bool(
        qs["friedmann_II_exact_match"]
        and qs["dH2_dt_matches_8piG_over_3_rhodot"]
        and approx["cases"]["radiation"]["is_O1_not_small"]
        and approx["cases"]["matter"]["is_O1_not_small"]
    )
    return {
        "quasistatic_derivation": qs,
        "approximation_size": approx,
        "all_checks_pass": passed,
    }


if __name__ == "__main__":             # guard: never write an artifact at import
    import json
    from casim.engine.particles._results_path import results_path

    result = run_all()
    path = results_path("F360_horizon_thermodynamics.json")
    with open(path, "w") as fh:
        json.dump(result, fh, indent=2)
    print(json.dumps(result, indent=2))
