# CASIM suite report — scale `smoke`

_2026-06-16 - 20:00_  ·  elapsed 0s  ·  COMPLETE

**SKIP: 5**

| group | item | status | t (s) | sizing | detail |
|---|---|---|---:|---|---|
| battery | casim::pytest | SKIP | 0.0 |  | 6 pytest files — pytest not installed (pip install pytest) |
| battery | priority::pytest | SKIP | 0.0 |  | no pytest-collectable files in group |
| battery | priority::scripts | SKIP | 0.0 |  | 16 standalone scripts skipped (--no-scripts) |
| battery | findings::pytest | SKIP | 0.0 |  | 54 pytest files — pytest not installed (pip install pytest) |
| battery | findings::scripts | SKIP | 0.0 |  | 100 standalone scripts skipped (--no-scripts) |
