# CASIM suite report — scale `1000x`

_2026-06-16 - 15:48_  ·  elapsed 3237s  ·  IN PROGRESS

**PASS: 7  RAN: 4  FAIL: 1  ERROR: 1**

| group | item | status | t (s) | sizing | detail |
|---|---|---|---:|---|---|
| battery | casim | PASS | 8.5 |  | 59 passed, 0 failed, 0 errors, 0 skipped |
| battery | priority | ERROR | 1.5 |  | pytest collection failed: no tests ran in 1.21s |
| battery | findings | FAIL | 2.0 |  | 0 passed, 0 failed, 1 errors, 0 skipped |
| scenarios | bcc_fields_companion | PASS | 42.7 | L=64, ticks=960 (×1024) |  |
| scenarios | bcc_weyl | PASS | 17.1 | L=64, ticks=3200 (×1024) |  |
| scenarios | beta_decay | RAN | 6.9 | L=64, ticks=384 (×1024) | completed; no hard gate (quantitative only) |
| scenarios | charge_photon | RAN | 16.2 | L=53, ticks=480 (×1084) | completed; no hard gate (quantitative only) |
| scenarios | confined_baryon | PASS | 542.0 | L=64, ticks=4800 (×1024) |  |
| scenarios | confined_baryon_free | PASS | 349.7 | L=64, ticks=4800 (×1024) |  |
| scenarios | dielectric_black_hole | RAN | 9.3 | L=256, ticks=0 (×64) | completed; no hard gate (quantitative only) |
| scenarios | fermion_w_backreaction | PASS | 2.5 | L=32, ticks=320 (×1024) |  |
| scenarios | gauge_mc | RAN | 2199.9 | L=12, ticks=1200 (×480) | completed; no hard gate (quantitative only) |
| scenarios | gluon_bcc | PASS | 37.9 | L=48, ticks=2400 (×1024) |  |
