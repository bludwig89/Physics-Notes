# CASIM suite report — scale `smoke`

_2026-06-16 - 19:11_  ·  elapsed 0s  ·  COMPLETE

**PASS: 1**

| group | item | status | t (s) | sizing | detail |
|---|---|---|---:|---|---|
| realspace | realspace_photon_patch | PASS | 0.1 | patch 32^3 (block 2) |  |
