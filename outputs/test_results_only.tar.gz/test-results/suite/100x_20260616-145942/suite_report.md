# CASIM suite report — scale `100x`

_2026-06-16 - 15:00_  ·  elapsed 36s  ·  COMPLETE

**PASS: 5**

| group | item | status | t (s) | sizing | detail |
|---|---|---|---:|---|---|
| realspace | blockspin_photon | PASS | 1.2 | patch 128^3 (block 8) |  |
| realspace | realspace_hydrogen_bohr | PASS | 5.6 | patch 128^3 (block 8) |  |
| realspace | realspace_neutron_1fm | PASS | 14.8 | patch 128^3 (block 8) |  |
| realspace | realspace_photon_patch | PASS | 0.1 | patch 128^3 (block 8) |  |
| realspace | realspace_proton_1fm | PASS | 14.7 | patch 128^3 (block 8) |  |
