# CASIM suite report — scale `smoke`

_2026-06-16 - 19:08_  ·  elapsed 9s  ·  COMPLETE

**PASS: 5**

| group | item | status | t (s) | sizing | detail |
|---|---|---|---:|---|---|
| realspace | blockspin_photon | PASS | 0.1 | patch 32^3 (block 2) |  |
| realspace | realspace_hydrogen_bohr | PASS | 1.4 | patch 32^3 (block 2) |  |
| realspace | realspace_neutron_1fm | PASS | 3.8 | patch 32^3 (block 2) |  |
| realspace | realspace_photon_patch | PASS | 0.0 | patch 32^3 (block 2) |  |
| realspace | realspace_proton_1fm | PASS | 3.9 | patch 32^3 (block 2) |  |
