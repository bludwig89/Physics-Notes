# CASIM suite report — scale `smoke`

_2026-06-16 - 20:09_  ·  elapsed 9s  ·  COMPLETE

**PASS: 2**

| group | item | status | t (s) | sizing | detail |
|---|---|---|---:|---|---|
| realspace | realspace_neutron_1fm | PASS | 4.6 | patch 32^3 (block 2) |  |
| realspace | realspace_proton_1fm | PASS | 4.5 | patch 32^3 (block 2) |  |
