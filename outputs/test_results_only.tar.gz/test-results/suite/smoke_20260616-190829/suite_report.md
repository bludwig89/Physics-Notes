# CASIM suite report — scale `smoke`

_2026-06-16 - 19:08_  ·  elapsed 0s  ·  COMPLETE

**SKIP: 3**

| group | item | status | t (s) | sizing | detail |
|---|---|---|---:|---|---|
| battery | casim | SKIP | 0.0 |  | pytest not installed (pip install pytest) |
| battery | priority | SKIP | 0.0 |  | pytest not installed (pip install pytest) |
| battery | findings | SKIP | 0.0 |  | pytest not installed (pip install pytest) |
