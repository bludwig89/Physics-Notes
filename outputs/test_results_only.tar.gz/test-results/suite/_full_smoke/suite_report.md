# CASIM suite report — scale `smoke`

_2026-06-16 - 19:14_  ·  elapsed 15s  ·  IN PROGRESS

**PASS: 11  RAN: 7  SKIP: 3**

| group | item | status | t (s) | sizing | detail |
|---|---|---|---:|---|---|
| battery | casim | SKIP | 0.0 |  | pytest not installed (pip install pytest) |
| battery | priority | SKIP | 0.0 |  | pytest not installed (pip install pytest) |
| battery | findings | SKIP | 0.0 |  | pytest not installed (pip install pytest) |
| scenarios | bcc_fields_companion | PASS | 0.2 | L=16, ticks=60 (×1) |  |
| scenarios | bcc_weyl | PASS | 0.1 | L=16, ticks=200 (×1) |  |
| scenarios | beta_decay | RAN | 0.0 | L=16, ticks=24 (×1) | completed; no hard gate (quantitative only) |
| scenarios | charge_photon | RAN | 0.0 | L=13, ticks=30 (×1) | completed; no hard gate (quantitative only) |
| scenarios | confined_baryon | PASS | 1.2 | L=16, ticks=300 (×1) |  |
| scenarios | confined_baryon_free | PASS | 0.8 | L=16, ticks=300 (×1) |  |
| scenarios | dielectric_black_hole | RAN | 0.1 | L=64, ticks=0 (×1) | completed; no hard gate (quantitative only) |
| scenarios | fermion_w_backreaction | PASS | 0.0 | L=8, ticks=20 (×1) |  |
| scenarios | gauge_mc | RAN | 4.6 | L=6, ticks=40 (×1) | completed; no hard gate (quantitative only) |
| scenarios | gluon_bcc | PASS | 0.2 | L=12, ticks=150 (×1) |  |
| scenarios | gravity_deflection | RAN | 0.1 | L=64, ticks=0 (×1) | completed; no hard gate (quantitative only) |
| scenarios | gravity_dynamic_selfsourced | PASS | 0.2 | L=24, ticks=60 (×1) |  |
| scenarios | njl_nucleon | RAN | 0.7 | L=4, ticks=1 (×1) | completed; no hard gate (quantitative only) |
| scenarios | njl_pion | RAN | 0.7 | L=4, ticks=1 (×1) | completed; no hard gate (quantitative only) |
| scenarios | particles_first_gen | PASS | 0.7 | L=16, ticks=60 (×1) |  |
| scenarios | photon_beam_all_fields | PASS | 1.2 | L=32, ticks=60 (×1) |  |
| scenarios | photon_pair | PASS | 0.2 | L=16, ticks=40 (×1) |  |
| scenarios | proton_bag | PASS | 3.7 | L=16, ticks=120 (×1) |  |
