# CASIM suite report — scale `1000x`

_2026-06-16 - 14:49_  ·  elapsed 0s  ·  IN PROGRESS

**SKIP: 3**

| group | item | status | t (s) | sizing | detail |
|---|---|---|---:|---|---|
| battery | casim | SKIP | 0.0 |  | pytest not installed (pip install pytest) |
| battery | priority | SKIP | 0.0 |  | pytest not installed (pip install pytest) |
| battery | findings | SKIP | 0.0 |  | pytest not installed (pip install pytest) |
