# CASIM suite report — scale `smoke`

_2026-06-16 - 19:08_  ·  elapsed 5s  ·  COMPLETE

**PASS: 3  RAN: 1**

| group | item | status | t (s) | sizing | detail |
|---|---|---|---:|---|---|
| scenarios | bcc_weyl | PASS | 0.1 | L=16, ticks=200 (×1) |  |
| scenarios | gauge_mc | RAN | 4.5 | L=6, ticks=40 (×1) | completed; no hard gate (quantitative only) |
| scenarios | photon_pair | PASS | 0.2 | L=16, ticks=40 (×1) |  |
| scenarios | z_even | PASS | 0.0 | L=16, ticks=60 (×1) |  |
